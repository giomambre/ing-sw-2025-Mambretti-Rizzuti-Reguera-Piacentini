package it.polimi.ingsw.model.enumerates;

public enum MeteorType {
    SmallMeteor,LargeMeteor,LightCannonFire,HeavyCannonFire
}
