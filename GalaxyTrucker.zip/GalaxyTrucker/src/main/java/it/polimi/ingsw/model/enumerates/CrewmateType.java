package it.polimi.ingsw.model.enumerates;

public enum CrewmateType {
    PinkAlien,BrownAlien,Astronaut,None
}
