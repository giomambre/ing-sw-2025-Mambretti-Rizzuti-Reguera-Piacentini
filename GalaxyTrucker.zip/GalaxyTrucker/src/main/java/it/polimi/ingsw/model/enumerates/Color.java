package it.polimi.ingsw.model.enumerates;

public enum Color {
    Red,Green,Blue,Yellow;
}
