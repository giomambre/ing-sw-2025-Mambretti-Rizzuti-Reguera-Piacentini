package it.polimi.ingsw.model.enumerates;

public enum Direction {
    North, East, South, West
}

