package it.polimi.ingsw.model.enumerates;

public enum Cargo {
    Blue,
    Yellow,
    Red,
    Green,
    Empty
}
