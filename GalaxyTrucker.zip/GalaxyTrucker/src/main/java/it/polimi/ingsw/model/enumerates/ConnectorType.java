package it.polimi.ingsw.model.enumerates;

public enum ConnectorType {
    Universal,
    Double,
    Single,
    Smooth,
    Cannon_Connector,
    Engine_Connector,
    Empty_Connector
}
